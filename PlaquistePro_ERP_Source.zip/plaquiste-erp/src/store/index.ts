// src/store/index.ts — Zustand global state
import { create } from 'zustand';
import { UserDoc, DeliveryDoc, StockDoc, IncidentDoc, NotificationDoc } from '../services/firebase';

interface AppState {
  // Auth
  user:          UserDoc | null;
  isLoading:     boolean;
  setUser:       (u: UserDoc | null) => void;
  setLoading:    (b: boolean) => void;

  // Data
  deliveries:    DeliveryDoc[];
  stock:         StockDoc[];
  incidents:     IncidentDoc[];
  notifications: NotificationDoc[];
  setDeliveries: (d: DeliveryDoc[]) => void;
  setStock:      (s: StockDoc[]) => void;
  setIncidents:  (i: IncidentDoc[]) => void;
  addNotif:      (n: NotificationDoc) => void;
  markRead:      (id: string) => void;

  // UI state
  theme:         'dark' | 'light';
  toggleTheme:   () => void;
  activeDelivery: DeliveryDoc | null;
  setActiveDelivery: (d: DeliveryDoc | null) => void;

  // Computed
  pendingCount:  () => number;
  lowStockItems: () => StockDoc[];
  unreadCount:   () => number;
}

export const useStore = create<AppState>((set, get) => ({
  user: null, isLoading: true,
  deliveries: [], stock: [], incidents: [], notifications: [],
  theme: 'dark', activeDelivery: null,

  setUser:    u  => set({ user: u }),
  setLoading: b  => set({ isLoading: b }),
  setDeliveries: d => set({ deliveries: d }),
  setStock:   s  => set({ stock: s }),
  setIncidents: i => set({ incidents: i }),

  addNotif: n => set(s => ({ notifications: [n, ...s.notifications].slice(0, 50) })),
  markRead: id => set(s => ({
    notifications: s.notifications.map(n => n.id === id ? { ...n, read: true } : n)
  })),

  toggleTheme: () => set(s => ({ theme: s.theme === 'dark' ? 'light' : 'dark' })),
  setActiveDelivery: d => set({ activeDelivery: d }),

  pendingCount:  () => get().deliveries.filter(d => d.status === 'pending' || d.status === 'assigned').length,
  lowStockItems: () => get().stock.filter(s => s.quantity <= s.minQuantity),
  unreadCount:   () => get().notifications.filter(n => !n.read).length,
}));
