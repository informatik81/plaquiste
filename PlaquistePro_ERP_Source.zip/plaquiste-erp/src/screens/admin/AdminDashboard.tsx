// src/screens/admin/AdminDashboard.tsx
import React, { useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity,
  Animated, Dimensions, RefreshControl
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { useStore } from '../../store';
import { Services } from '../../services/firebase';

const { width } = Dimensions.get('window');

export function AdminDashboard({ navigation }: any) {
  const { deliveries, stock, incidents, lowStockItems, pendingCount } = useStore();
  const fadeAnim  = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim,  { toValue:1, duration:400, useNativeDriver:true }),
      Animated.timing(slideAnim, { toValue:0, duration:400, useNativeDriver:true }),
    ]).start();
  }, []);

  const stats = {
    total:     deliveries.length,
    inTransit: deliveries.filter(d => d.status === 'in_transit').length,
    delivered: deliveries.filter(d => d.status === 'delivered').length,
    incidents: incidents.filter(i => i.status === 'open').length,
    lowStock:  lowStockItems().length,
  };

  const kpis = [
    { label:'Livraisons', value: stats.total,     icon:'📦', colors:['#3b82f6','#1d4ed8'], sub:`${stats.inTransit} en cours`,  page:'Livraisons' },
    { label:'Livrés',     value: stats.delivered,  icon:'✅', colors:['#10b981','#059669'], sub:`${Math.round(stats.delivered/Math.max(stats.total,1)*100)}% taux`, page:'Livraisons' },
    { label:'Stock',      value: stats.lowStock,   icon:'⚠️', colors:['#f59e0b','#d97706'], sub:'produits sous seuil', page:'Stock' },
    { label:'Incidents',  value: stats.incidents,  icon:'🚨', colors:['#ef4444','#dc2626'], sub:'à résoudre',          page:'Incidents' },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <Animated.View style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>

        {/* KPI GRID */}
        <View style={styles.kpiGrid}>
          {kpis.map((k, i) => (
            <Animated.View key={k.label}
              style={[styles.kpiCard, { transform: [{ translateY: slideAnim }] }]}
            >
              <TouchableOpacity
                activeOpacity={0.85}
                onPress={() => navigation.navigate(k.page)}
              >
                <LinearGradient colors={k.colors} style={styles.kpiGradient} start={{x:0,y:0}} end={{x:1,y:1}}>
                  <Text style={styles.kpiIcon}>{k.icon}</Text>
                  <Text style={styles.kpiValue}>{k.value}</Text>
                  <Text style={styles.kpiLabel}>{k.label}</Text>
                  <Text style={styles.kpiSub}>{k.sub}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          ))}
        </View>

        {/* RECENT DELIVERIES */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Livraisons récentes</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Livraisons')}>
              <Text style={styles.seeAll}>Voir tout →</Text>
            </TouchableOpacity>
          </View>
          {deliveries.slice(0, 4).map(d => (
            <DeliveryCard key={d.id} delivery={d} onPress={() => navigation.navigate('DeliveryDetail', { id: d.id })} />
          ))}
        </View>

        {/* STOCK ALERTS */}
        {lowStockItems().length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>⚠️ Alertes stock</Text>
            {lowStockItems().slice(0, 3).map(s => (
              <View key={s.id} style={styles.stockAlert}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.stockName}>{s.name}</Text>
                  <View style={styles.progressWrap}>
                    <View style={[styles.progressBar, {
                      width: `${Math.min(100, s.quantity / s.minQuantity * 100)}%` as any,
                      backgroundColor: s.quantity <= s.minQuantity * 0.5 ? '#ef4444' : '#f59e0b'
                    }]} />
                  </View>
                </View>
                <Text style={[styles.stockQty, {
                  color: s.quantity <= s.minQuantity * 0.5 ? '#ef4444' : '#f59e0b'
                }]}>{s.quantity}/{s.minQuantity}</Text>
              </View>
            ))}
          </View>
        )}

      </Animated.View>
    </ScrollView>
  );
}

function DeliveryCard({ delivery, onPress }: any) {
  const statusConfig: Record<string, any> = {
    pending:    { label: '⏳ En attente', color: '#f59e0b', bg: 'rgba(245,158,11,.1)' },
    in_transit: { label: '🚛 Transit',    color: '#3b82f6', bg: 'rgba(59,130,246,.1)' },
    delivered:  { label: '✅ Livré',      color: '#10b981', bg: 'rgba(16,185,129,.1)' },
    incident:   { label: '⚠️ Incident',   color: '#ef4444', bg: 'rgba(239,68,68,.1)'  },
  };
  const s = statusConfig[delivery.status] || statusConfig.pending;

  return (
    <TouchableOpacity style={styles.deliveryCard} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.deliveryBar, { backgroundColor: s.color }]} />
      <View style={{ flex: 1 }}>
        <Text style={styles.deliveryClient}>{delivery.clientName}</Text>
        <Text style={styles.deliveryAddr} numberOfLines={1}>📍 {delivery.address}</Text>
        <View style={styles.chipRow}>
          <View style={[styles.chip, { backgroundColor: s.bg }]}>
            <Text style={[styles.chipText, { color: s.color }]}>{s.label}</Text>
          </View>
          <View style={styles.chip}>
            <Text style={styles.chipText}>{delivery.reference}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container:     { flex:1, backgroundColor:'#080c14' },
  kpiGrid:       { flexDirection:'row', flexWrap:'wrap', padding:12, gap:10 },
  kpiCard:       { width:(width-34)/2, borderRadius:16, overflow:'hidden' },
  kpiGradient:   { padding:18, borderRadius:16 },
  kpiIcon:       { fontSize:26, marginBottom:8 },
  kpiValue:      { fontSize:36, fontWeight:'800', color:'#fff', letterSpacing:-1.5 },
  kpiLabel:      { fontSize:12, color:'rgba(255,255,255,.75)', marginTop:3 },
  kpiSub:        { fontSize:10, color:'rgba(255,255,255,.5)', fontFamily:'Courier', marginTop:5 },
  section:       { marginHorizontal:12, marginBottom:16 },
  sectionHeader: { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:10 },
  sectionTitle:  { fontSize:16, fontWeight:'700', color:'#f0f4ff' },
  seeAll:        { fontSize:12, color:'#3b82f6', fontWeight:'600' },
  deliveryCard:  { backgroundColor:'#111827', borderWidth:1, borderColor:'#1e2d47', borderRadius:12, padding:14, marginBottom:8, flexDirection:'row', gap:12, alignItems:'center' },
  deliveryBar:   { width:3, borderRadius:2, alignSelf:'stretch' },
  deliveryClient:{ fontSize:16, fontWeight:'700', color:'#f0f4ff', marginBottom:2 },
  deliveryAddr:  { fontSize:12, color:'#8899bb', marginBottom:8 },
  chipRow:       { flexDirection:'row', gap:6, flexWrap:'wrap' },
  chip:          { paddingHorizontal:9, paddingVertical:3, borderRadius:20, backgroundColor:'#1a2235' },
  chipText:      { fontSize:11, color:'#8899bb', fontFamily:'Courier', fontWeight:'500' },
  stockAlert:    { backgroundColor:'#111827', borderWidth:1, borderColor:'#1e2d47', borderRadius:10, padding:12, marginBottom:7, flexDirection:'row', gap:12, alignItems:'center' },
  stockName:     { fontSize:13, fontWeight:'600', color:'#f0f4ff', marginBottom:6 },
  progressWrap:  { height:4, backgroundColor:'#1a2235', borderRadius:2, overflow:'hidden', width:'100%' },
  progressBar:   { height:'100%', borderRadius:2 },
  stockQty:      { fontSize:12, fontWeight:'700', fontFamily:'Courier', minWidth:50, textAlign:'right' },
});
