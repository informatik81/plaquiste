// ═══════════════════════════════════════════════
// src/screens/auth/LoginScreen.tsx
// ═══════════════════════════════════════════════
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Animated, KeyboardAvoidingView, Platform, ActivityIndicator,
  Alert
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { Services } from '../../services/firebase';

export function LoginScreen() {
  const [email, setEmail]     = useState('');
  const [password, setPass]   = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const shakeAnim = useRef(new Animated.Value(0)).current;

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue:-10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 6,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue:-6,  duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0,  duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const login = async () => {
    if (!email || !password) { setError('Renseignez votre e-mail et mot de passe'); shake(); return; }
    setLoading(true); setError('');
    try {
      await Services.auth.login(email.trim(), password);
    } catch (e: any) {
      const msgs: Record<string, string> = {
        'auth/user-not-found':    'Aucun compte pour cet e-mail.',
        'auth/wrong-password':    'Mot de passe incorrect.',
        'auth/invalid-credential':'Identifiants incorrects.',
        'auth/too-many-requests': 'Trop de tentatives. Réessayez plus tard.',
      };
      setError(msgs[e.code] || 'Erreur de connexion.');
      shake();
    } finally { setLoading(false); }
  };

  return (
    <LinearGradient colors={['#080c14','#0d1220','#080c14']} style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS==='ios'?'padding':'height'} style={styles.inner}>

        {/* LOGO */}
        <View style={styles.logoWrap}>
          <View style={styles.logoIcon}><Text style={styles.logoEmoji}>🏗️</Text></View>
          <Text style={styles.logoTitle}>PlaquistePro</Text>
          <Text style={styles.logoSub}>ERP · LIVRAISONS</Text>
        </View>

        {/* CARD */}
        <Animated.View style={[styles.card, { transform:[{ translateX: shakeAnim }] }]}>

          {error ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>⚠️ {error}</Text>
            </View>
          ) : null}

          <Text style={styles.fieldLabel}>Adresse e-mail</Text>
          <TextInput
            style={styles.input}
            value={email}
            onChangeText={setEmail}
            placeholder="nom@entreprise.fr"
            placeholderTextColor="#3d5070"
            keyboardType="email-address"
            autoCapitalize="none"
            returnKeyType="next"
          />

          <Text style={styles.fieldLabel}>Mot de passe</Text>
          <TextInput
            style={styles.input}
            value={password}
            onChangeText={setPass}
            placeholder="••••••••"
            placeholderTextColor="#3d5070"
            secureTextEntry
            returnKeyType="done"
            onSubmitEditing={login}
          />

          <TouchableOpacity
            style={[styles.loginBtn, loading && { opacity:.7 }]}
            onPress={login}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.loginBtnText}>Se connecter</Text>
            }
          </TouchableOpacity>

          <Text style={styles.version}>PlaquistePro ERP v2.0</Text>
        </Animated.View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const ls = StyleSheet.create({
  container:    { flex:1 },
  inner:        { flex:1, alignItems:'center', justifyContent:'center', padding:24 },
  logoWrap:     { alignItems:'center', marginBottom:32 },
  logoIcon:     { width:68, height:68, borderRadius:18, backgroundColor:'#1d4ed8', alignItems:'center', justifyContent:'center', marginBottom:14, shadowColor:'#3b82f6', shadowOffset:{width:0,height:8}, shadowOpacity:.4, shadowRadius:16 },
  logoEmoji:    { fontSize:32 },
  logoTitle:    { fontSize:28, fontWeight:'800', color:'#f0f4ff', letterSpacing:-.6 },
  logoSub:      { fontSize:11, color:'#8899bb', fontFamily:'Courier', letterSpacing:2, marginTop:4 },
  card:         { width:'100%', maxWidth:380, backgroundColor:'#111827', borderRadius:20, padding:28, borderWidth:1, borderColor:'#1e2d47', shadowColor:'#000', shadowOffset:{width:0,height:16}, shadowOpacity:.5, shadowRadius:32 },
  errorBox:     { backgroundColor:'rgba(239,68,68,.1)', borderWidth:1, borderColor:'rgba(239,68,68,.2)', borderRadius:8, padding:11, marginBottom:14 },
  errorText:    { fontSize:13, color:'#fca5a5' },
  fieldLabel:   { fontSize:10, fontWeight:'700', color:'#8899bb', fontFamily:'Courier', letterSpacing:1, textTransform:'uppercase', marginBottom:7 },
  input:        { backgroundColor:'#0d1220', borderWidth:1.5, borderColor:'#1e2d47', borderRadius:10, padding:13, color:'#f0f4ff', fontSize:16, marginBottom:14 },
  loginBtn:     { backgroundColor:'#3b82f6', borderRadius:11, padding:15, alignItems:'center', marginTop:6, shadowColor:'#3b82f6', shadowOffset:{width:0,height:4}, shadowOpacity:.35, shadowRadius:12 },
  loginBtnText: { fontSize:16, fontWeight:'700', color:'#fff' },
  version:      { textAlign:'center', fontSize:11, color:'#3d5070', fontFamily:'Courier', marginTop:18 },
});
Object.assign(styles, ls); // merge with module styles below
const styles = {} as any;
Object.assign(styles, ls);


// ═══════════════════════════════════════════════
// src/screens/client/ClientTrackingScreen.tsx
// ═══════════════════════════════════════════════
export function ClientTrackingScreen({ navigation }: any) {
  const { user, deliveries } = require('../../store').useStore();

  const myDeliveries = deliveries.filter((d: any) =>
    d.clientId === user?.clientId
  );

  const STEPS = ['Confirmé', 'Préparé', 'En route', 'Livré'];
  const STEP_ICONS = ['📋', '🏭', '🚛', '✅'];
  const statusToStep: Record<string, number> = {
    pending: 1, assigned: 1, in_transit: 2, delivered: 3, incident: 2
  };

  return (
    <require('react-native').ScrollView style={{ flex:1, backgroundColor:'#080c14' }} showsVerticalScrollIndicator={false}>
      <View style={{ padding:16 }}>
        {myDeliveries.length === 0 ? (
          <View style={{ alignItems:'center', padding:40 }}>
            <Text style={{ fontSize:48, opacity:.2 }}>📦</Text>
            <Text style={{ fontSize:18, fontWeight:'700', color:'#f0f4ff', marginTop:12 }}>Aucune livraison</Text>
            <Text style={{ fontSize:13, color:'#8899bb', marginTop:6 }}>Vos livraisons apparaîtront ici</Text>
          </View>
        ) : myDeliveries.map((d: any) => {
          const step = statusToStep[d.status] ?? 0;
          return (
            <View key={d.id} style={{ backgroundColor:'#111827', borderWidth:1, borderColor:'#1e2d47', borderRadius:16, padding:18, marginBottom:12 }}>
              <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:16 }}>
                <View>
                  <Text style={{ fontSize:16, fontWeight:'700', color:'#f0f4ff' }}>{d.reference}</Text>
                  <Text style={{ fontSize:12, color:'#8899bb', marginTop:2 }}>📍 {d.address}</Text>
                </View>
                {d.status === 'in_transit' && (
                  <View style={{ backgroundColor:'rgba(16,185,129,.12)', borderRadius:20, paddingHorizontal:11, paddingVertical:5, borderWidth:1, borderColor:'rgba(16,185,129,.2)' }}>
                    <Text style={{ fontSize:11, color:'#10b981', fontWeight:'700', fontFamily:'Courier' }}>EN ROUTE</Text>
                  </View>
                )}
              </View>

              {/* TRACKING STEPS */}
              <View style={{ flexDirection:'row', alignItems:'center', marginBottom:14 }}>
                {STEPS.map((s, i) => (
                  <View key={i} style={{ flex:1, alignItems:'center' }}>
                    <View style={{ flexDirection:'row', alignItems:'center', width:'100%', position:'absolute', top:14 }}>
                      {i > 0 && <View style={{ flex:1, height:2, backgroundColor: i <= step ? '#10b981' : '#1e2d47' }} />}
                      <View style={{ width:12, flexShrink:0 }} />
                      {i < STEPS.length-1 && <View style={{ flex:1, height:2, backgroundColor: i < step ? '#10b981' : '#1e2d47' }} />}
                    </View>
                    <View style={{ width:30, height:30, borderRadius:15, backgroundColor: i <= step ? (i < step ? '#10b981' : '#3b82f6') : '#1e2d47', alignItems:'center', justifyContent:'center', borderWidth:2, borderColor: i <= step ? (i < step ? '#10b981' : '#3b82f6') : '#2a3d5c', zIndex:1 }}>
                      <Text style={{ fontSize:13 }}>{i <= step ? (i < step ? '✓' : STEP_ICONS[i]) : STEP_ICONS[i]}</Text>
                    </View>
                    <Text style={{ fontSize:9, color: i <= step ? '#8899bb' : '#3d5070', fontFamily:'Courier', marginTop:5, textAlign:'center' }}>{s.toUpperCase()}</Text>
                  </View>
                ))}
              </View>

              {/* DRIVER INFO */}
              {d.driverName && (
                <View style={{ backgroundColor:'#0d1220', borderRadius:10, padding:12 }}>
                  <Text style={{ fontSize:11, color:'#8899bb', fontFamily:'Courier', marginBottom:4 }}>CHAUFFEUR</Text>
                  <Text style={{ fontSize:14, fontWeight:'600', color:'#f0f4ff' }}>🚛 {d.driverName}</Text>
                  {d.status === 'in_transit' && (
                    <Text style={{ fontSize:12, color:'#10b981', marginTop:3 }}>Livraison en cours...</Text>
                  )}
                </View>
              )}

              {/* MATERIALS */}
              <Text style={{ fontSize:11, color:'#3d5070', fontFamily:'Courier', marginTop:12, marginBottom:6 }}>
                {d.items?.length || 0} ARTICLE{(d.items?.length || 0) > 1 ? 'S' : ''}
              </Text>
              {d.items?.map((it: any, i: number) => (
                <Text key={i} style={{ fontSize:12, color:'#8899bb' }}>• {it.qty} {it.unit} {it.name}</Text>
              ))}
            </View>
          );
        })}
      </View>
    </require('react-native').ScrollView>
  );
}


// ═══════════════════════════════════════════════
// src/navigation/AppNavigator.tsx
// ═══════════════════════════════════════════════
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';

const Tab   = createBottomTabNavigator();
const Stack = createStackNavigator();

function AdminTabs() {
  const { pendingCount, lowStockItems, unreadCount } = require('../store').useStore();
  const screens = [
    { name:'Dashboard',  comp: require('./admin/AdminDashboard').AdminDashboard,  icon:'🏠' },
    { name:'Livraisons', comp: require('./admin/DeliveriesListScreen').DeliveriesListScreen, icon:'📦', badge: pendingCount() },
    { name:'Stock',      comp: require('./admin/StockScreen').StockScreen,        icon:'🏭', badge: lowStockItems().length },
    { name:'Clients',    comp: require('./admin/ClientsScreen').ClientsScreen,    icon:'👥' },
    { name:'Stats',      comp: require('./admin/StatsScreen').StatsScreen,        icon:'📊' },
  ];
  return (
    <Tab.Navigator
      screenOptions={{ headerShown:false, tabBarStyle:{ backgroundColor:'#0d1220', borderTopColor:'#1e2d47', height:60, paddingBottom:8 }, tabBarActiveTintColor:'#3b82f6', tabBarInactiveTintColor:'#3d5070', tabBarLabelStyle:{ fontSize:10, fontWeight:'600' } }}
    >
      {screens.map(s => (
        <Tab.Screen key={s.name} name={s.name} component={s.comp}
          options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize:20 }}>{s.icon}</Text>,
            tabBarBadge: s.badge && s.badge > 0 ? s.badge : undefined,
            tabBarBadgeStyle:{ backgroundColor:'#ef4444', fontSize:9 } }} />
      ))}
    </Tab.Navigator>
  );
}

function DriverTabs() {
  const { pendingCount } = require('../store').useStore();
  return (
    <Tab.Navigator
      screenOptions={{ headerShown:false, tabBarStyle:{ backgroundColor:'#0d1220', borderTopColor:'#1e2d47', height:60, paddingBottom:8 }, tabBarActiveTintColor:'#10b981', tabBarInactiveTintColor:'#3d5070' }}
    >
      <Tab.Screen name="driver" component={require('./driver/DriverScreen').DriverScreen}
        options={{ title:'Livraisons', tabBarIcon:()=><Text style={{fontSize:20}}>🚛</Text>, tabBarBadge: pendingCount() || undefined }} />
      <Tab.Screen name="stock" component={require('./admin/StockScreen').StockScreen}
        options={{ title:'Stock', tabBarIcon:()=><Text style={{fontSize:20}}>🏭</Text> }} />
      <Tab.Screen name="incidents" component={require('./admin/IncidentsScreen').IncidentsScreen}
        options={{ title:'Incidents', tabBarIcon:()=><Text style={{fontSize:20}}>🚨</Text> }} />
    </Tab.Navigator>
  );
}

function ClientTabs() {
  return (
    <Tab.Navigator
      screenOptions={{ headerShown:false, tabBarStyle:{ backgroundColor:'#0d1220', borderTopColor:'#1e2d47', height:60, paddingBottom:8 }, tabBarActiveTintColor:'#3b82f6', tabBarInactiveTintColor:'#3d5070' }}
    >
      <Tab.Screen name="tracking" component={ClientTrackingScreen}
        options={{ title:'Mes livraisons', tabBarIcon:()=><Text style={{fontSize:20}}>📍</Text> }} />
    </Tab.Navigator>
  );
}

export function AppNavigator() {
  const { user, isLoading } = require('../store').useStore();

  if (isLoading) {
    return (
      <View style={{ flex:1, backgroundColor:'#080c14', alignItems:'center', justifyContent:'center' }}>
        <Text style={{ fontSize:48, marginBottom:16 }}>🏗️</Text>
        <Text style={{ color:'#8899bb', fontFamily:'Courier', fontSize:12, letterSpacing:2 }}>CHARGEMENT...</Text>
      </View>
    );
  }

  const RoleTabs = user?.role === 'admin' ? AdminTabs : user?.role === 'driver' ? DriverTabs : ClientTabs;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown:false }}>
        {!user
          ? <Stack.Screen name="Login" component={LoginScreen} />
          : (
            <>
              <Stack.Screen name="Main" component={RoleTabs} />
              <Stack.Screen name="Signature" component={require('./driver/SignatureScreen').SignatureScreen}
                options={{ presentation:'modal', headerShown:true, headerTitle:'Signature de livraison', headerStyle:{ backgroundColor:'#0d1220' }, headerTintColor:'#f0f4ff' }} />
              <Stack.Screen name="DeliveryDetail" component={require('./admin/DeliveryDetailScreen').DeliveryDetailScreen}
                options={{ presentation:'modal', headerShown:true, headerTitle:'Détail livraison', headerStyle:{ backgroundColor:'#0d1220' }, headerTintColor:'#f0f4ff' }} />
              <Stack.Screen name="NewDelivery" component={require('./admin/NewDeliveryScreen').NewDeliveryScreen}
                options={{ presentation:'modal', headerShown:true, headerTitle:'Nouvelle livraison', headerStyle:{ backgroundColor:'#0d1220' }, headerTintColor:'#f0f4ff' }} />
            </>
          )
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}


// ═══════════════════════════════════════════════
// App.tsx — ENTRY POINT
// ═══════════════════════════════════════════════
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useEffect } from 'react';
import { registerForPushNotifications } from './services/notificationService';
import { Services as Svc } from './services/firebase';

const queryClient = new QueryClient();

export default function App() {
  const { setUser, setLoading, setDeliveries, setStock, setIncidents, user } =
    require('./store').useStore();

  useEffect(() => {
    // Auth listener
    const unsubAuth = Svc.auth.onChange(async (u: any) => {
      if (u) {
        // Fetch user profile
        const userDoc = { uid: u.uid, email: u.email, displayName: u.displayName || u.email, role: 'admin' };
        setUser(userDoc as any);
        setLoading(false);
        // Register push
        await registerForPushNotifications(u.uid);
      } else {
        setUser(null);
        setLoading(false);
      }
    });
    return unsubAuth;
  }, []);

  useEffect(() => {
    if (!user) return;
    let unsubDel: any, unsubStock: any, unsubInc: any;
    if (user.role === 'admin') {
      unsubDel   = Svc.deliveries.listenAll(setDeliveries);
      unsubStock = Svc.stock.listenAll(setStock);
      unsubInc   = Svc.incidents.listenAll(setIncidents);
    } else if (user.role === 'driver') {
      unsubDel   = Svc.deliveries.listenByDriver(user.uid, setDeliveries);
      unsubStock = Svc.stock.listenAll(setStock);
    } else if (user.role === 'client' && user.clientId) {
      unsubDel   = Svc.deliveries.listenByClient(user.clientId, setDeliveries);
    }
    return () => { unsubDel?.(); unsubStock?.(); unsubInc?.(); };
  }, [user?.uid, user?.role]);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <QueryClientProvider client={queryClient}>
          <AppNavigator />
        </QueryClientProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
